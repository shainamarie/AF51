import psycopg2
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, render_template, request, g, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from forms import CreateAccount
from flask_bootstrap import Bootstrap
from flask_wtf import Form
from wtforms import StringField, PasswordField
from wtforms.validators import InputRequired
from datetime import datetime
from configparser import ConfigParser
from models import Entry, EntryP, Register, EntryF, EntryB
import json
import time
from xml.etree import ElementTree
from decimal import Decimal
from bs4 import BeautifulSoup
import requests

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:carrotcake092814@localhost:5432/AF51'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'flaskimplement'
app.debug = True
db = SQLAlchemy(app)
bootstrap = Bootstrap(app)

class User(db.Model):
    __tablename__ = "User"

    id = db.Column(db.Integer, primary_key=True)

    firstname = db.Column(db.String(80), unique=False)
    middlename = db.Column(db.String(80), unique=False)
    lastname = db.Column(db.String(80), unique=False)
    username = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(80), unique=False)
    officerrole = db.Column(db.String(80), unique=False)

    def __init__(self, firstname='', middlename='', lastname='', username='', password='', officerole=''):
        self.firstname = firstname
        self.middlename = middlename
        self.lastname = lastname
        self.username = username
        self.password = password
        self.officerrole = officerole

class nlogs(db.Model):

    __tablename__ = "nlogs"


    username = db.Column(db.String(80), unique=False)
    actions = db.Column(db.String(80), unique=False)
    natureOfCollection = db.Column(db.String(80), unique=False)
    amount = db.Column(db.String(80), unique=False)
    payor = db.Column(db.String(80), unique=False)
    transtime = db.Column(db.String(80), primary_key=True)

    def __init__(self, username, actions, natureOfCollection, amount, payor, transtime):

        self.username = username
        self.actions = actions
        self.natureOfCollection = natureOfCollection
        self.amount = amount
        self.payor = payor
        self.transtime = transtime

print "Program Start"
 
def config(filename='database.ini', section='postgresql'):
    # create a parser
    parser = ConfigParser()
    # read config file
    parser.read(filename)
 
    # get section, default to postgresql
    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise Exception('Section {0} not found in the {1} file'.format(section, filename))
 
    return db


print "Table created successfully"

def connect():
    """ Connect to the PostgreSQL database server """
    conn = None
    try:
        # read connection parameters
        params = config()
 
        # connect to the PostgreSQL server
        print "Connecting to the PostgreSQL database..."
        conn = psycopg2.connect(**params)
 
        # create a cursor
        cur = conn.cursor()
        
 # execute a statement
        print 'PostgreSQL database version:'
        cur.execute('SELECT version()')
 
        # display the PostgreSQL database server version
        db_version = cur.fetchone()
        print db_version
       
     # close the communication with the PostgreSQL
        cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print error
    finally:
        if conn is not None:
            conn.close()
            print "Database connection closed."


print "Program End"


@app.route('/signup')
def index():
    return render_template('homeC.html')


@app.route('/create')
def create():
    form = CreateAccount()
    return render_template('createC.html', form=form)


@app.route('/createaccount', methods=['POST', 'GET'])
def createaccount():
    form = CreateAccount()
    if request.method == "POST":
        if form.validate_on_submit():
            if User.query.filter_by(username=form.username.data).first():
                msg = "Username Already Taken"
                return render_template('createresultC.html', msg=msg)
            elif User.query.filter_by(password=form.password.data).first():
                msg = "Password Already Taken"
                return render_template('createresultC.html', msg=msg)
            else:
                user = User(firstname=form.firstname.data, middlename=form.middlename.data, lastname=form.lastname.data,
                            username=form.username.data, password=form.password.data, officerole=form.officerrole.data)
                db.session.add(user)
                db.session.commit()
                naive_dt = datetime.now()
                userlogs = nlogs(username=form.username.data, actions="Registered", natureOfCollection='', amount='as new user', payor='', transtime=naive_dt)
                db.session.add(userlogs)
                db.session.commit()

                msg = "ADDED"
                return render_template('resultC.html', msg=msg)

    return render_template('createC.html', form=form)


@app.route('/manage')
def manage():
    return render_template('manageC.html')


@app.route('/delete')
def delete():
    form = CreateAccount()
    myUser = User.query.all()
    return render_template('deleteC.html', form=form, myUser=myUser)


@app.route('/deleteaccount', methods=['POST', 'GET'])
def deleteaccount():
    form = CreateAccount()
    if request.method == "POST":
        idno = request.form['id']
        user = User.query.filter_by(id=idno).first()
        if user is None:
            msg = "ID not exists"
            return render_template('result.html', msg=msg)
        else:
            db.session.delete(user)
            db.session.commit()
            naive_dt = datetime.now()
            userlogs = nlogs(username=form.username.data, actions="Deleted", natureOfCollection='', amount='as new user', payor='', transtime=naive_dt)
            db.session.add(userlogs)
            db.session.commit()

            msg = "DELETED"
            return render_template('resultC.html', msg=msg)

    return render_template('deleteC.html', form=form)

#CREATE





#
@app.route('/query')
def queryQ():
    if g.user:


        return render_template('transaction.html',user=g.user)

    return redirect(url_for('home'))





@app.route('/transact', methods=['POST', 'GET'])
def transact():
  if g.user:
      if request.method == 'POST':
          try:
              start_date = request.form['start']
              end_date = request.form['end']

              print start_date
              print end_date

              conn = psycopg2.connect(database="AF51", user="postgres", password="carrotcake092814", host="localhost", port="5432")
              cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)


              cur.execute("""SELECT * FROM payments WHERE transactiondate BETWEEN  %s AND %s""", (start_date,end_date))
              rows = cur.fetchall()
              conn.close()
              print rows

          except:
              print ("Error")

          finally:
              msg = ("People Who Paid Between " + start_date + " and " + end_date + "")
              return render_template('resultQ.html', rows=rows, msg=msg,user=g.user)
  
  return redirect(url_for('home'))


def add_parameter(ent):
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully"
   cur = conn.cursor()

   cur.execute('''INSERT INTO parameters (nature,over,notover,officer) VALUES (%s,%s,%s,%s)''', (ent.nofcollection, ent.over, ent.nover, ent.officer))            
               
   print "Good"
   conn.commit()
   conn.close()



def add_entry(ent):
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully"
   cur = conn.cursor()
   


   cur.execute('''INSERT INTO form (payor, nature1, nature1amt, nature2, nature2amt, nature3, nature3amt, insurance, total, amtwords, paymentmethod, draweebank, draweenum, draweedate, receiptno, officer, collectiondate) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)''', (ent.payor, ent.nature1, ent.nature1amt, ent.nature2, ent.nature2amt, ent.nature3, ent.nature3amt, ent.insurance, ent.total, ent.amtwords, ent.paymentmethod, ent.draweebank, ent.draweenum, ent.draweedate, ent.receiptno, ent.officer, ent.collectiondate))            
               
   print "Good"
   conn.commit()
   conn.close()



def add_parameterB(ent):
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully"
   cur = conn.cursor()
   


   cur.execute('''INSERT INTO "BPI" (cn,txp,tn,rp,ba,bgy,ctgy,ha,memo,vu,isdby) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)''', ent)           
               
   print "Good"
   conn.commit()
   conn.close()

def add_entryF(ent):
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully"
   cur = conn.cursor()
   


   cur.execute('''INSERT INTO formType (noc, amount) VALUES (%s,%s)''', (nofcollection, amt))            
               
   print "Good"
   conn.commit()
   conn.close()

def add_logForm(ent):
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully"
   cur = conn.cursor()
   


   cur.execute('''INSERT INTO nlogs (username, actions, natureOfCollection, amount, payor, transtime) VALUES (%s,%s,%s,%s,%s,current_timestamp)''', (entlogs.username,entlogs.actions,entlogs.nature1,entlogs.nature1amt,entlogs.payor,))            
               
   print "Good"
   conn.commit()
   conn.close()
 


@app.route('/', methods=['GET','POST'])
def home(username=None):
    if request.method == 'POST':
        session.pop('user', None)
        user_candidate= request.form['username']
        pass_candidate = request.form['password']
        conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
        print "Opened database successfully"
        print user_candidate
        print pass_candidate
        cur = conn.cursor()


        user1=cur.execute("""SELECT * FROM users WHERE user_id=%s""", (user_candidate,))
        pass1=cur.execute("""SELECT * FROM users WHERE pass=%s""",(pass_candidate,))
        
        data=cur.fetchone()
                       
        conn.close()

      

        

        print user1
        print pass1
        print data
        try:    
            conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
            cur = conn.cursor()
            
            if user_candidate is '':
                return render_template("req_username.html")
            elif pass_candidate is '':
                return render_template("req_password.html")
            elif user_candidate not in data and pass_candidate not in data:
                session['user'] = request.form['username']
                return render_template("error_input.html")
            elif user_candidate  in data and pass_candidate  in data:

                session['user'] = request.form['username']
                return render_template("header-second-bar.html", user = user_candidate)

            elif user_candidate not in username:
                return render_template("error_input.html")
        except Exception:
            return render_template("error_input.html")
    else:

        return render_template("login.html")


@app.route('/home')
def homenotlogin():
    if g.user:
       user = str(g.user)
       print user
       return render_template("header-second-bar.html", user = g.user)

    return redirect(url_for('home'))


@app.route('/landing')
def landing():
    if g.user:
       user = str(g.user)
       print user
       return render_template("header-second-bar.html", user = user)

    return redirect(url_for('home'))

@app.before_request
def before_request():
    g.user = None
    if 'user' in session:
        g.user = session['user']

@app.route('/logout')
def logout():
    session.pop('user',None)
    return redirect(url_for('home'))

@app.route('/test')
def test1():
    return render_template("req_password.html")


@app.route('/logs')
def logs():
    if g.user:
        try:
           conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
           cur = conn.cursor()
           cur.execute("SELECT * from nlogs ORDER BY transtime DESC")
           rows = cur.fetchall()
           print rows
        except:
           print ("Failed to open")

        return render_template('logs.html', rows=rows, user = g.user)

    return redirect(url_for('home'))



@app.route('/query')
def query():
    if g.user:
        return render_template("query.html")

    return redirect(url_for('home'))


@app.route('/user')
def user():

 if g.user:
   
         
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully" 
   cur = conn.cursor()

   rows = cur.execute("SELECT * from User WHERE 'username'=%s",(g.user,))
   
  

   return render_template("user.html", rows=rows, user = g.user)
 return redirect(url_for('home'))
        


























@app.route('/form')
def formfinal():
    if g.user:


        user = str(g.user)
        x1 = 10
        x2 = 2000

        receiptnorng = range(x1, x2)
        actions="Applied"
        receiptno = receiptnorng[0]
        naive_dt = time.strftime("%m/%d/%Y")



    # Let's print our table out.
        print "Added {0} {1}, {2}, to the list".format(first_name, last_name, age
        conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
        print "Opened database successfully" 
        cur = conn.cursor()

        cur.execute("""SELECT * FROM parameters""")
        rows = cur.fetchall();
        print rows

      
        return render_template("indextest.html", rows=rows, user=user, receiptno= receiptno, date = naive_dt)

    return redirect(url_for('home'))














@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():

   if g.user:


        if request.method == 'POST':

#UPPER PANE
            collectiondate = naive_dt = datetime.now() 
            payor = request.form['payor']
            receiptno = request.form['OR']
            paymentmethod = request.form['paymentmethod']
            naive_dt = time.strftime("%m/%d/%Y")
            message = request.form['message']

#LOWER PANE


            url_to_scrape = 'http://localhost:5000/form'
            r = requests.get(url_to_scrape)
            soup = BeautifulSoup(r.text)
            inmates_list = []
            for table_row in soup.select("table.inmatesList tr"):

              cells = table_row.findAll('td')


              if len(cells) > 0:

                nature = cells[0].text.strip()

                natureamt = cells[1].text.strip()

                inmate = {'nature': nature, 'nature': natureamt}
                inmates_list.append(inmate)

              # Let's print our table out.
            print "Added {0} {1}, to the list".format(nature, natureamt)
            print inmates_list



            actions="Applied"


            ent = Entry(payor, nature1, nature1amt, nature2, nature2amt, nature3, nature3amt, insurance, total, amtwords, paymentmethod, receiptno, officer, collectiondate)
            add_entry(ent)



            entlogs = Entry(g.user, actions, nature1, nature1amt, payor, collectiondate)
            add_logForm(entlogs)
            receiptnorng = range(x1+1, x2)
            msg = "Record successfully added"
        return render_template("indextest.html", rows=rows, user=g.user, receiptno= receiptno, date = naive_dt)

   return redirect(url_for('home'))

















@app.route('/addparameters/delete/', methods=['GET','POST'])
def delete_row():

   if request.method == 'POST':
  
         conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
         print "Opened database successfully" 
         cur = conn.cursor()
         todelete =  request.form['row_delete']
         print todelete
         cur.execute("DELETE FROM parameters WHERE nature=%s",(todelete,))
         conn.commit()
         return redirect(url_for('addparameter'))






@app.route('/addparameters',methods = ['POST', 'GET'])
def addparameter():

 if g.user:
   if request.method == 'POST':

        
         nofcollection = request.form['param']
         over = float(request.form['param2'])
         over = format(over,'.2f')
         nover = float(request.form['param3'])
         nover = format(nover,'.2f')
         officer = g.user

         ent = EntryP(nofcollection,over,nover,officer)
         add_parameter(ent)

   current_time = datetime.now()

   Date = current_time.strftime('%m/%d/%Y')
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully" 
   cur = conn.cursor()

   cur.execute("""SELECT * FROM parameters""")
   rows = cur.fetchall();
   print rows




  
   return render_template("admintest.html", rows=rows)
 return redirect(url_for('home'))
        
@app.route('/issuebusinesspermit/delete/', methods=['GET','POST'])
def delete_rowB():

   if request.method == 'POST':
  
         conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
         print "Opened database successfully" 
         cur = conn.cursor()
         todelete =  request.form['row_delete']
         print todelete
         cur.execute("""DELETE FROM "BPI" WHERE cn=%s""",(todelete,))
         conn.commit()
         return redirect(url_for('issuebusinesspermit'))

@app.route('/issuebusinesspermit',methods = ['POST', 'GET'])
def issuebusinesspermit():

 if g.user:
   if request.method == 'POST':

        
         cn = request.form['param']
         print cn+"___________________________________________________________________"
         txp = request.form['param2']
         tn = request.form['param3']
         rp = request.form['param4']
         ba = request.form['param5']
         bgy = request.form['param6']
         ctgy = request.form['param7']
         ha = request.form['param8']
         memo = request.form['param9']
         vu = request.form['param10']
         officer = str(g.user)

         ent = cn,txp,tn,rp, ba, bgy,ctgy,ha,memo,vu,officer
         add_parameterB(ent)

   current_time = datetime.now()

   Date = current_time.strftime('%m/%d/%Y')
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully" 
   cur = conn.cursor()

   cur.execute("""SELECT * FROM "BPI" """)
   rows = cur.fetchall();
   print rows




  
   return render_template("BPI.html", rows=rows, user=g.user)
 return redirect(url_for('home'))
        


@app.route('/postquarterlydue',methods = ['POST', 'GET'])
def postquarterlydue():

 if g.user:
   if request.method == 'POST':

        
         nofcollection = request.form['param']
         over = float(request.form['param2'])
         over = format(over,'.2f')
         nover = float(request.form['param3'])
         nover = format(nover,'.2f')
         officer = g.user

         ent = EntryP(nofcollection,over,nover,officer)
         add_parameter(ent)

   current_time = datetime.now()

   Date = current_time.strftime('%m/%d/%Y')
   conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
   print "Opened database successfully" 
   cur = conn.cursor()

   cur.execute("""SELECT * FROM parameters""")
   rows = cur.fetchall();
   print rows




  
   return render_template("postquarterly.html", rows=rows)
 return redirect(url_for('home'))
        




@app.route('/masterlist')
def masterlist():
    if g.user:
      
        return render_template("mastermain.html" , user = g.user)

    return redirect(url_for('home'))





@app.route('/businesspermits',methods = ['POST', 'GET'])
def masterlistpermits():
    if g.user:
        conn = psycopg2.connect(database = "AF51", user = "postgres", password = "carrotcake092814", host = "127.0.0.1", port = "5432")
        print "Opened database successfully" 
        cur = conn.cursor()

        cur.execute("""SELECT * FROM "BPI" """)
        rows = cur.fetchall();
        print rows

        return render_template("bpmasterlist.html" , user=g.user, rows=rows)

    return redirect(url_for('home'))
